---
title: Mapas de sentidos
tags:
categories:
date: 2022-07-04
lastMod: 2022-07-10
---
# Epígrafes

  + {{< logseq/orgQUOTE >}}Algo que no vemos nos protege de algo no entendemos. Lo que no vemos es la cultura, en su manifestación intrapsíquica o interna. Lo que no entendemos es el caos que dio origen a la cultura. Si la estructura de la cultura se altera inadvertidamente, el caos regresa. Y hacemos cualquier cosa, lo que sea, para defendernos de ese regreso.{{< / logseq/orgQUOTE >}}

    + {{< logseq/orgQUOTE >}}El hecho mismo de que un problema general haya atrapado y asimilado a una persona en su totalidad es garantía de que el hablante lo ha experimentado realmente, y de que tal vez haya obtenido algo a partir de su sufrimiento. En ese caso nos reflejará el problema en su vida personal y, por tanto, nos mostrará un verdad.{{< / logseq/orgQUOTE >}}
[[Jung. C. G. (1978). Vol. 9 Part. 2. Aion: Researches into the Phenomenology of the Self.]]


# Puntos de partida

{{< logseq/orgQUOTE >}}Mis convicciones religiosas, **que para empezar eran muy defectuosas**, desaparecieron cuando era muy joven. Mi confianza en el socialismo (es decir, en la utopía política) desapareció cuando de mi cuenta de que el mundo no era meramente un lugar de economía. Mi fe en la ideología me abandonó cuando empecé a ver la identificación ideológica en sí misma un problema profundo y misterioso. No podía aceptar las explicaciones teóricas que me ofrecía mi campo de estudio, y ya no disponía de razones prácticas para seguir avanzando en la dirección que me había propuesto originalmente. Obtuve mi título de grado tras tres años y dejé la universidad. **Todas mis creencias (que habían puesto orden al caos de mi existencia, al menos temporalmente) se habían revelado ilusorias, ya no les veía sentido a las cosas**. Quedaba a la deriva; no sabía qué hacer ni qué pensar.{{< / logseq/orgQUOTE >}}

  + {{< logseq/orgQUOTE >}}¿Por qué? Personas teóricamente normales y bien adaptadas se ocupaban de sus asuntos de manera prosaica, si nada ocurriera. ¿Por qué no estaban alterados? ¿Acaso no prestaban atención? ¿No la prestaba yo?{{< / logseq/orgQUOTE >}}

Visita a la cárcel: 
{{< logseq/orgQUOTE >}}¿Cómo podía el hombre con el que acababa de hablar, ese hombre aparentemente tan normal (y al parecer tan irrelevante) haber hecho una cosa tan horrible?{{< / logseq/orgQUOTE >}}

background-color:: #264c9b
{{< logseq/orgQUOTE >}}Todas las cosas que "creía" eran cosas que me parecían que sonaban buenas, admirables, respetables, valerosas. Pero no eran mis cosas, las había robado. En su mayoría las habías sacado de libros. Después de haberlas "entendido", en abstracto, **presumía que tenía derecho a ellas, presumía que podía adoptarlas como su fueran mías, presumía que eran "yo"**. Mi cabeza estaba llena de ideas de otros, llena de argumentos que yo no había podido refutar lógicamente. Por aquel entonces **no sabía que un argumento irrefutable no es necesariamente cierto, ni que el derecho a identificarse con ciertas cosas debe ganarse**.{{< / logseq/orgQUOTE >}}

  + {{< logseq/orgQUOTE >}}Fue Jung quien formuló el concepto de _persona_: las máscara que "fingía individualidad". Según Jung, adoptar esa máscara nos permitía, a nosotros y a los que estaban a nuestro alrededor, creer que éramos auténticos.{{< / logseq/orgQUOTE >}}

    + {{< logseq/orgQUOTE >}}Cuando analizamos a la persona retiramos las máscara y descubrimos que lo que parecía individual es, en el fondo, colectivo... En cierto sentido todo ello es real, y sin embargo, en relación con la individualidad esencial... se trata de un convenio en donde los demás tienen generalmente más influencia.{{< / logseq/orgQUOTE >}}
[[Jung. C. G. (1978). Vol. 9 Part. 2. Aion: Researches into the Phenomenology of the Self.]]


{{< logseq/orgQUOTE >}}Desde entonces, siempre he intentado entender la capacidad humana, **mi propia capacidad, para el mal**, sobre todo para esos males asociados a la **creencia**{{< / logseq/orgQUOTE >}}

  + {{< logseq/orgQUOTE >}}Hay que admitir que el contenido arquetípico inconsciente colectivo puede asumir con frecuencia formas grotescas y espantosas en sueños y fantasías. Así que ni siquiera el racionalista más recalcitrante es inmune a pesadillas perturbadoras y miedos inquietantes.{{< / logseq/orgQUOTE >}}

  + {{< logseq/orgQUOTE >}}El esclarecimiento psicológico de... imágenes que no pueden pasarse por alto en silencio ni ignorarse ciegamente, lleva por lógica a las profundidades de la fenomenología religiosa... la cual incluye **mitología**, **folclore** y **psicología primitiva**... tesoro de formas arquetípicas de las que el doctor puede extraer **paralelismos útiles y comparaciones reveladoras** con el fin de **calmar y clarificar una consciencia desconcertada**. Es absolutamente necesario proporcionar... cierto contexto con el fin de **hacerlas más inteligibles**. La experiencia muestra que la mejor manera de hacerlo es mediante el uso de **materiales mitológicos comparativos**{{< / logseq/orgQUOTE >}}
[[Jung. C. G. (1968). Vol. 9. Part. 1. The Archetypes and the Collective unconscious.]]


    + {{< logseq/orgQUOTE >}}El estudio de esos **materiales mitológicos comparativos** de hecho, hizo que mis espantosos sueños desapareciera. Pero la cura que me proporcionó este estudio la compré al precio de una **transformación completa y a menudo dolorosa**.{{< / logseq/orgQUOTE >}}

      + {{< logseq/orgQUOTE >}}Descubrí que las creencias conforman el mundo, de una manera muy real: las creencias _son_ el mundo en un sentido más que metafísico.{{< / logseq/orgQUOTE >}}

      + {{< logseq/orgQUOTE >}}He llegado a convencerme que el mundo que es _creencia_ es ordenado; que hay **absolutos morales universales**... Creo que los individuos y las sociedades que **desdeñan esos absolutos (ya sea por ignorancia o por una oposición deliberada)** están condenados a la desgracia y, tarde o temprano, a la disolución.{{< / logseq/orgQUOTE >}}

      + {{< logseq/orgQUOTE >}}Los significados de los sustratos más profundos de los sistemas de creencias pueden hacerse **explícitamente comprensible**, incluso al pensador racional escéptico, y que, una vez expuestos de ese modo, pueden ser experimentados como algo **fascinante, profundo y necesario**.{{< / logseq/orgQUOTE >}}

      + {{< logseq/orgQUOTE >}}Aprendía **por qué la gente hace la guerra**... Qué puede hacerse para **mejorar esta tendencia**... Que el aspecto terrible de la vida puede podría ser, de hecho, una **condición previa para la existencia de la vida** y que es posible considerar esa **condición previa como comprensible y aceptable**.{{< / logseq/orgQUOTE >}}

# Primer resumen

  + El mundo puede entenderse de manera válida como un foro para la acción, además de como un lugar de las cosas.

  + El mundo para las cosas

    + Describimos el mundo por medio de la ciencia y sus métodos formales

{{< logseq/orgQUOTE >}}La ciencia permite una determinación cada vez más precisa de las propiedades validables y consensuadas de las cosas... Aquellos que aceptan la perspectiva científica (_como estado óptimo o posibilidad de perfección_) olvidan que un abismo infranqueable divide actualmente lo que _es_ de lo que _debería ser_.{{< / logseq/orgQUOTE >}}

  + El mundo para la acción

    + Describimos en paralelo el mundo a través de las técnicas del relato (el mito, la literatura, el drama)

{{< logseq/orgQUOTE >}}Implicación para la configuración del esquema interpretativo que produce o guía la acción... Los defensores de una visión mitológica del mundo tienden a ver las afirmaciones de sus credos como algo indistinguible del "hecho" empírico.{{< / logseq/orgQUOTE >}}

    + Elementos constitutivos del mundo como foro para la acción

      + El territorio inexplorado

        + La Gran Madre

        + La naturaleza

        + Lo creativo y lo destructivo

        + Fuente inicial y final de todas las cosas determinadas

      + El territorio explorado

        + El Gran Padre

        + La cultura

        + Lo protector y lo tiránico

        + El saber ancestral acumulativo

      + El proceso mediador entre lo explorado y lo inexplorado

        + El Hijo Divino

        + El individuo arquetípico

        + El Mundo creativo exploratorio y el adversario vengador

    + La exposición al territorio inexplorado

      + Produce miedo si no hay protección

      + Protección del individuo por imitación ritual del Gran Padre

        + Adopción de la identidad de grupo

        + Confiere predictibilidad de las interacciones sociales

      + Si la integración se hace absoluta no puede manifestarse la actualización del proceso creativo exploratorio

        + Todo tiene que ser controlado

        + No se le permite existir a lo desconocido

        + _Idiotización_ patológica

        + Negación de la anomalía

      + Aumenta la agresión social a causa de la falta de capacidad de adaptación

      + Se declara la identificación con el orgullo luciferino: "Todo lo que sé es todo lo que hace falta saber".

        + Asunción totalitaria de la omnisciencia

        + Adopción del lugar de Dios por parte de la "razón"

      + Reconocimiento _humilde_ del proceso exploratorio creativo de lo desconocido

        + Reconstruye el sentido de aceptación de la estructura adaptativa de la vida

        + Participación en la intersección explorada e inexplorada

          + Adaptación saludable de la sociedad

          + Adaptación saludable del individuo mediante la identificación con el arquetipo de héroe que mantiene y trasciende al grupo

Exploración de las cosas
{{< logseq/orgQUOTE >}}Explorar algo, _descubrir qué es_, significa sobre todo descubrir su significación para la obtención de un resultado motriz dentro de un contexto social particular, y solo de manera más particular determinar su precisa naturaleza sensible objetiva o material. Eso eso es [[conocimiento]] en su sentido más básico, y con frecuencia constituye un conocimiento suficiente.{{< / logseq/orgQUOTE >}}

  + Elementos de la exploración

    + Lo que hay

    + Qué hacer con lo que hay

    + Que existe una diferencia entre _saber lo que hay_ y _saber qué hacer con lo que hay_

    + Determinar la diferencia

  + Ejemplos

    + 1. Niña explorando una estructura de cristal

      + Interactúa con los aspectos físicos del objeto

        + Interacción empírica

      + Es reprendida por su madre

        + Estatus socioculturalmente determinado

      + "Todo lo que encuentra la niña es naturaleza dual. Todo _es_ algo y todo _significa_ algo"

      + "La distinción entre _esencia_ y _significación_ no está necesariamente trazada"

      + "La _significación_ de algo tiene de "manera natural" a asimilarse al objeto mismo. Después de todo, el objeto es la causa próxima o el estímulo que "da origen" a la acción llevada a cabo en su presencia.

    + 2. El niño y la expresión "_He visto a un hombre temible_"

      + Resulta difícil darse cuenta de la naturaleza subjetiva del miedo

      + Sentir la amenaza como parte del mundo "real"

    + 3. La narración capta de manera precisa la naturaleza de la experiencia bruta

      + Las cosas _son_ temibles

      + La gente _es_ irritante

      + Los acontecimiento _son_ prometedores

      + La comida _es_ satisfactoria

    + 4. La mente moderna asume la superación de lo _mágico_

{{< logseq/orgQUOTE >}}Como individuos medievales, ni siquiera necesitamos que la persona genere afecto. con el ícono basta.{{< / logseq/orgQUOTE >}}

      + Impresión o terror frente a una figura cultural suficientemente poderosa

        + Ídolo intelectual

        + Superestrella deportiva

        + Actor de cine

        + Líder político

        + El papa

        + Una belleza célebre

  + El _significado_ precede a la exploración de las _cosas_

{{< logseq/orgQUOTE >}}Debemos saber lo que las cosas son no para saber que lo que son sino para _hacer un seguimiento de lo que significan_: para entender lo que significan para nuestro comportamiento{{< / logseq/orgQUOTE >}}

{{< logseq/orgQUOTE >}}Han hecho falta **años de disciplina firme y entrenamiento intelectual, religioso, protocientífico y científico**, para producir una mente capaz de concentrarse en fenómenos que todavía no son o ya no son intrínsecamente atractivos de una manera inmediata, para producir **una mente que entiende lo _real_ con algo separable de lo _relevante_**{{< / logseq/orgQUOTE >}}

    + La alquimia como ejemplo de la indistinción de los dominio de la _acción_ y de las _cosas_

{{< logseq/orgQUOTE >}}Las cosas, para la mente alquimista, venían por tanto caracterizadas en gran parte por su naturaleza _moral_: por su impacto en lo que podríamos describir como afecto, emoción o motivación; venían caracterizadas por tanto por su _relevancia_ o _valor_... Fue una gran proeza de la ciencia despojar el _afecto_ de la _percepción_, por así decirlo, y permitir una descripción de las experiencias puramente en términos de sus rasgos aprehensibles consensuados.{{< / logseq/orgQUOTE >}}

{{< logseq/orgQUOTE >}}¡Qué distinto le parecía el mundo al hombre medieval! Para él la tierra estaba eternamente fija e inmóvil  en el centro del universo, circundada por la trayectoria de un sol que con gran solicitud le aportaba su calor. Los hombres eran todos hijos de Dios y estaban bajo el cuidado del Altísimo, que los preparaba para la bendición eterna; y todos sabían exactamente lo que debían hacer y cómo debían conducirse a fin de elevarse sobre el mundo corruptible y alcanzar una existencia incorruptible y dichosa. a nosotros esa vida ya no nos parece real, ni en nuestro sueños. Hace mucho que la ciencia natural ha rasgado ese velo encantador.{{< / logseq/orgQUOTE >}}
[[Jung. C. G. (1933). Modern man in search of a soul]]


      + Es ha llevado a que podamos manipular las cosas con gran facilidad y pericia

      + Sin embargo, seguimos teniendo emociones que no entendemos generados por cosas que _no deberían_ afectarnos

    + Más poder tecnológico y sistemas de valores inconscientes

{{< logseq/orgQUOTE >}}Hemos perdido el universo mítico de la mente preexperimental, o al menos hemos dejado de propiciar su desarrollo. Esa pérdida ha dejado nuestro creciente poder tecnológico más peligrosamente a merced de nuestros sistemas de valoración, que todavía son inconscientes.{{< / logseq/orgQUOTE >}}
